# HSK 3 – Học tiếng Trung

Trang web học tiếng Trung HSK 3 gồm 20 bài. Mỗi bài có ngữ pháp, luyện dịch câu và phân biệt từ dễ nhầm.

- Một file duy nhất: `index.html` (không cần cài đặt, mở bằng trình duyệt là chạy)
- Tiến độ học được lưu trong trình duyệt (localStorage)
- Hỗ trợ ẩn/hiện pinyin, nghe đọc (tùy trình duyệt), giao diện sáng/tối

## Chạy trên GitHub Pages
Settings → Pages → Source: `Deploy from a branch` → Branch: `main` / `(root)` → Save.
Sau ít phút trang sẽ có tại `https://<tên-github>.github.io/<tên-repo>/`.
